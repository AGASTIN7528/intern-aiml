import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(AppRoot());
}

/* -------------------------
   Global Theme Notifier
   ------------------------- */
ValueNotifier<ThemeMode> themeNotifier = ValueNotifier(ThemeMode.light);

/* -------------------------
   App Root
   ------------------------- */
class AppRoot extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (context, mode, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'AI-Powered Mobile App Risk Analyzer',
          themeMode: mode,
          theme: ThemeData(
            brightness: Brightness.light,
            colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
            useMaterial3: true,
            scaffoldBackgroundColor: Colors.transparent,
          ),
          darkTheme: ThemeData(
            brightness: Brightness.dark,
            colorScheme: ColorScheme.fromSeed(
                seedColor: Colors.indigo, brightness: Brightness.dark),
            useMaterial3: true,
            scaffoldBackgroundColor: Colors.transparent,
          ),
          home: MainShell(),
        );
      },
    );
  }
}

/* -------------------------
   Models
   ------------------------- */
class AppModel {
  final String appName;
  final String packageName;
  final String versionName;
  int riskScore;
  List<String> permissions;

  AppModel({
    required this.appName,
    required this.packageName,
    required this.versionName,
    this.riskScore = 0,
    this.permissions = const [],
  });
}

/* -------------------------
   MainShell (holds background + nav)
   ------------------------- */
class MainShell extends StatefulWidget {
  @override
  _MainShellState createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> with TickerProviderStateMixin {
  int _selectedIndex = 0;
  late final PageController _pageController;
  late final AnimationController _bgAnimController;

  List<AppModel> apps = [];

  // MethodChannel for Android
  static const platform = MethodChannel('com.example.ai/appScanner');

  @override
  void initState() {
    super.initState();
    _pageController = PageController(initialPage: _selectedIndex);
    _bgAnimController =
        AnimationController(vsync: this, duration: Duration(seconds: 10))
          ..repeat();
    // initial mock apps until first scan
    apps = [
      AppModel(
          appName: "Loading...",
          packageName: "",
          versionName: "",
          riskScore: 0,
          permissions: [])
    ];
  }

  @override
  void dispose() {
    _pageController.dispose();
    _bgAnimController.dispose();
    super.dispose();
  }

  void onNavTap(int idx) {
    setState(() => _selectedIndex = idx);
    _pageController.animateToPage(idx,
        duration: Duration(milliseconds: 450), curve: Curves.easeOut);
  }

  /* -------------------------
     Perform real Android scan
     ------------------------- */
  Future<void> performAndroidScan({Duration duration = const Duration(seconds: 0)}) async {
    try {
      final List<dynamic> fetchedApps =
          await platform.invokeMethod('getInstalledAppsWithPermissions');

      List<AppModel> scannedApps = fetchedApps.map((app) {
        final perms = List<String>.from(app['permissions'] ?? []);
        return AppModel(
          appName: app['appName'] ?? 'Unknown',
          packageName: app['packageName'] ?? '',
          versionName: app['versionName'] ?? '',
          permissions: perms,
          riskScore: Random().nextInt(101), // mock riskScore for demo
        );
      }).toList();

      setState(() {
        apps = scannedApps;
      });
    } catch (e) {
      print("Error scanning apps: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        AnimatedGradientBackground(animation: _bgAnimController),
        Scaffold(
          backgroundColor: Colors.transparent,
          body: SafeArea(
            child: PageView(
              controller: _pageController,
              physics: NeverScrollableScrollPhysics(),
              children: [
                DashboardPage(apps: apps),
                AppsPage(apps: apps),
                ScanPage(onScan: performAndroidScan, apps: apps),
                AIInsightsPage(apps: apps),
                SettingsPage(),
              ],
            ),
          ),
          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              color: Theme.of(context).scaffoldBackgroundColor.withOpacity(0.15),
            ),
            child: BottomNavigationBar(
              currentIndex: _selectedIndex,
              onTap: onNavTap,
              type: BottomNavigationBarType.fixed,
              showUnselectedLabels: true,
              items: [
                BottomNavigationBarItem(
                    icon: Icon(Icons.dashboard_outlined), label: 'Dashboard'),
                BottomNavigationBarItem(
                    icon: Icon(Icons.apps_outlined), label: 'Apps'),
                BottomNavigationBarItem(
                    icon: Icon(Icons.search_outlined), label: 'Scan'),
                BottomNavigationBarItem(
                    icon: Icon(Icons.insights_outlined), label: 'AI Insights'),
                BottomNavigationBarItem(
                    icon: Icon(Icons.settings_outlined), label: 'Settings'),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

/* -------------------------
   Animated Gradient Background
   ------------------------- */
class AnimatedGradientBackground extends StatelessWidget {
  final Animation<double> animation;
  AnimatedGradientBackground({required this.animation});

  final List<List<Color>> palettes = [
    [Color(0xFFff6b6b), Color(0xFFf7d794), Color(0xFFf9a825)],
    [Color(0xFF6a11cb), Color(0xFF2575fc), Color(0xFF66d9ff)],
    [Color(0xFF00b09b), Color(0xFF96c93d), Color(0xFFfbc531)],
    [Color(0xFFff758c), Color(0xFFff7eb3), Color(0xFFb983ff)],
  ];

  List<Color> lerpPalette(List<Color> a, List<Color> b, double t) {
    return List<Color>.generate(a.length, (i) {
      return Color.lerp(a[i % a.length], b[i % b.length], t) ?? a[i % a.length];
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: animation,
      builder: (context, child) {
        final double t = animation.value;
        final int idx = (t * palettes.length).floor() % palettes.length;
        final double localT = (t * palettes.length) - idx;
        final List<Color> from = palettes[idx % palettes.length];
        final List<Color> to = palettes[(idx + 1) % palettes.length];
        final List<Color> mixed =
            lerpPalette(from, to, Curves.easeInOut.transform(localT));

        return Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment(-1.0 + 0.4 * sin(t * 2 * pi), -0.8),
              end: Alignment(1.0 - 0.4 * cos(t * 2 * pi), 0.8),
              colors: mixed,
              stops: [0.0, 0.5, 1.0],
            ),
          ),
          child: Opacity(
            opacity: 0.95,
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment(
                      0.0 + 0.3 * cos(t * 2 * pi), 0.0 + 0.3 * sin(t * 2 * pi)),
                  radius: 1.2,
                  colors: mixed.map((c) => c.withOpacity(0.06)).toList(),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

/* -------------------------
   Utility: Risk color
   ------------------------- */
Color riskColor(int score) {
  if (score >= 75) return Colors.redAccent;
  if (score >= 50) return Colors.orangeAccent;
  if (score >= 25) return Colors.amber;
  return Colors.greenAccent;
}

/* -------------------------
   DASHBOARD PAGE
   ------------------------- */
class DashboardPage extends StatelessWidget {
  final List<AppModel> apps;
  DashboardPage({required this.apps});

  int highRiskCount() => apps.where((a) => a.riskScore >= 75).length;
  int medRiskCount() => apps.where((a) => a.riskScore >= 50 && a.riskScore < 75).length;
  int lowRiskCount() => apps.where((a) => a.riskScore < 50).length;

  @override
  Widget build(BuildContext context) {
    final total = apps.length;
    return Padding(
      padding: EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(height: 6),
        Text("Dashboard", style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        SizedBox(height: 8),
        Text("Overview of installed apps and AI insights",
            style: TextStyle(color: Colors.white.withOpacity(0.85))),
        SizedBox(height: 18),
        Row(
          children: [
            Expanded(
                child: StatCard(title: "Total Apps", value: "$total", icon: Icons.apps)),
            SizedBox(width: 12),
            Expanded(
                child: StatCard(
                    title: "High Risk",
                    value: "${highRiskCount()}",
                    icon: Icons.warning,
                    valueColor: Colors.redAccent)),
          ],
        ),
        SizedBox(height: 12),
        Row(
          children: [
            Expanded(
                child: StatCard(
                    title: "Medium Risk",
                    value: "${medRiskCount()}",
                    icon: Icons.report_gmailerrorred)),
            SizedBox(width: 12),
            Expanded(
                child: StatCard(
                    title: "Low Risk",
                    value: "${lowRiskCount()}",
                    icon: Icons.check_circle_outline,
                    valueColor: Colors.greenAccent)),
          ],
        ),
        SizedBox(height: 18),
        Text("Recent apps", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        SizedBox(height: 8),
        Expanded(
          child: ListView.builder(
            itemCount: apps.length,
            itemBuilder: (context, i) {
              final a = apps[i];
              return AnimatedCard(
                child: ListTile(
                  tileColor: Theme.of(context).cardColor.withOpacity(0.2),
                  leading: CircleAvatar(child: Text(a.appName[0]), backgroundColor: Colors.black12),
                  title: Text(a.appName, style: TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text(a.packageName),
                  trailing: Chip(
                      label: Text("${a.riskScore}"),
                      backgroundColor: riskColor(a.riskScore).withOpacity(0.15)),
                ),
              );
            },
          ),
        ),
      ]),
    );
  }
}

/* -------------------------
   StatCard widget
   ------------------------- */
class StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final Color? valueColor;
  StatCard({required this.title, required this.value, required this.icon, this.valueColor});

  @override
  Widget build(BuildContext context) {
    final color = valueColor ?? Theme.of(context).colorScheme.primary;
    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 16),
        child: Row(children: [
          Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(8)),
            child: Icon(icon, color: color),
          ),
          SizedBox(width: 12),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: TextStyle(fontSize: 14, color: Colors.grey[700])),
            SizedBox(height: 6),
            Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
          ])
        ]),
      ),
    );
  }
}

/* -------------------------
   AnimatedCard helper
   ------------------------- */
class AnimatedCard extends StatefulWidget {
  final Widget child;
  AnimatedCard({required this.child});

  @override
  _AnimatedCardState createState() => _AnimatedCardState();
}

class _AnimatedCardState extends State<AnimatedCard> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<Offset> _offset;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: Duration(milliseconds: 450));
    _offset = Tween<Offset>(begin: Offset(0, .03), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
    _ctrl.forward();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SlideTransition(position: _offset, child: widget.child);
  }
}

/* -------------------------
   APPS PAGE
   ------------------------- */
class AppsPage extends StatelessWidget {
  final List<AppModel> apps;
  AppsPage({required this.apps});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(height: 6),
        Text("Apps", style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
        SizedBox(height: 8),
        Expanded(
          child: ListView.builder(
            itemCount: apps.length,
            itemBuilder: (context, i) {
              final a = apps[i];
              return Padding(
                padding: EdgeInsets.symmetric(vertical: 6),
                child: AppCard(app: a),
              );
            },
          ),
        )
      ]),
    );
  }
}

/* -------------------------
   AppCard
   ------------------------- */
class AppCard extends StatelessWidget {
  final AppModel app;
  AppCard({required this.app});

  @override
  Widget build(BuildContext context) {
    final color = riskColor(app.riskScore);
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 4,
      child: ListTile(
        contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        leading: CircleAvatar(child: Text(app.appName[0]), backgroundColor: Colors.black12),
        title: Text(app.appName, style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(app.packageName),
        trailing: Chip(label: Text("${app.riskScore}"), backgroundColor: color.withOpacity(0.12)),
        onTap: () => Navigator.push(
            context, MaterialPageRoute(builder: (_) => AppDetailPage(app: app))),
      ),
    );
  }
}

/* -------------------------
   App Detail Page
   ------------------------- */
class AppDetailPage extends StatelessWidget {
  final AppModel app;
  AppDetailPage({required this.app});

  @override
  Widget build(BuildContext context) {
    final c = riskColor(app.riskScore);
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(title: Text(app.appName)),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(children: [
          Row(children: [
            CircleAvatar(radius: 28, child: Text(app.appName[0]), backgroundColor: Colors.black12),
            SizedBox(width: 12),
            Expanded(child: Text(app.appName, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
            Chip(label: Text("${app.riskScore}"), backgroundColor: c.withOpacity(0.12)),
          ]),
          SizedBox(height: 16),
          Card(
            elevation: 4,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Padding(
              padding: EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text("Permissions", style: TextStyle(fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                Wrap(spacing: 8, runSpacing: 8, children: app.permissions.map((p) => Chip(label: Text(p))).toList()),
                SizedBox(height: 12),
                Text("Version: ${app.versionName}", style: TextStyle(color: Colors.grey[600])),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}

/* -------------------------
   SCAN PAGE
   ------------------------- */
class ScanPage extends StatefulWidget {
  final Future<void> Function({Duration duration}) onScan;
  final List<AppModel> apps;
  ScanPage({required this.onScan, required this.apps});

  @override
  _ScanPageState createState() => _ScanPageState();
}

class _ScanPageState extends State<ScanPage> with SingleTickerProviderStateMixin {
  bool scanning = false;
  String status = "Idle";
  late final AnimationController _scanPulse;

  @override
  void initState() {
    super.initState();
    _scanPulse = AnimationController(vsync: this, duration: Duration(milliseconds: 900))
      ..repeat(reverse: true);
  }

  @override
  void dispose() {
    _scanPulse.dispose();
    super.dispose();
  }

  Future<void> _startScan() async {
    setState(() {
      scanning = true;
      status = "Scanning apps...";
    });
    await widget.onScan();
    await Future.delayed(Duration(milliseconds: 250));
    setState(() {
      scanning = false;
      status = "Scan complete — ${widget.apps.length} apps analyzed";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16),
      child: Column(children: [
        SizedBox(height: 6),
        Text("Scan", style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
        SizedBox(height: 12),
        Text("Run a quick scan to compute risk scores.", style: TextStyle(color: Colors.white.withOpacity(0.9))),
        SizedBox(height: 18),
        ScaleTransition(
          scale: Tween(begin: 1.0, end: 1.3).animate(CurvedAnimation(parent: _scanPulse, curve: Curves.easeInOut)),
          child: ElevatedButton.icon(
            icon: Icon(Icons.search),
            label: Text(scanning ? "Scanning..." : "Start Scan"),
            onPressed: scanning ? null : _startScan,
          ),
        ),
        SizedBox(height: 18),
        Text(status),
      ]),
    );
  }
}

/* -------------------------
   AI INSIGHTS PAGE
   ------------------------- */
class AIInsightsPage extends StatelessWidget {
  final List<AppModel> apps;
  AIInsightsPage({required this.apps});

  @override
  Widget build(BuildContext context) {
    final riskyApps = apps.where((a) => a.riskScore >= 50).toList();
    return Padding(
      padding: EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text("AI Insights", style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
        SizedBox(height: 12),
        Text("Apps that may pose potential risks", style: TextStyle(color: Colors.white70)),
        SizedBox(height: 16),
        Expanded(
          child: ListView.builder(
            itemCount: riskyApps.length,
            itemBuilder: (context, i) {
              final a = riskyApps[i];
              return Card(
                elevation: 3,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: ListTile(
                  title: Text(a.appName),
                  subtitle: Text(a.packageName),
                  trailing: Chip(label: Text("${a.riskScore}"), backgroundColor: riskColor(a.riskScore).withOpacity(0.2)),
                ),
              );
            },
          ),
        ),
      ]),
    );
  }
}

/* -------------------------
   SETTINGS PAGE
   ------------------------- */
class SettingsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16),
      child: Column(children: [
        SizedBox(height: 6),
        Text("Settings", style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
        SizedBox(height: 12),
        ListTile(
          leading: Icon(Icons.brightness_6),
          title: Text("Toggle Theme"),
          onTap: () => themeNotifier.value =
              themeNotifier.value == ThemeMode.light ? ThemeMode.dark : ThemeMode.light,
        ),
      ]),
    );
  }
}
