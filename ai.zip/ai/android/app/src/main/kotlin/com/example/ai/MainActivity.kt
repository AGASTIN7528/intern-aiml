package com.example.ai  // your package name

import android.content.pm.PackageManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val CHANNEL = "app_scanner"  // same as used in Flutter Dart

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                if (call.method == "getInstalledAppsWithPermissions") {
                    val pm = packageManager
                    val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                    val apps = packages.map {
                        val permissions = try {
                            pm.getPackageInfo(it.packageName, PackageManager.GET_PERMISSIONS)
                                .requestedPermissions?.toList() ?: emptyList()
                        } catch (e: Exception) { emptyList<String>() }

                        mapOf(
                            "appName" to pm.getApplicationLabel(it).toString(),
                            "packageName" to it.packageName,
                            "versionName" to try { pm.getPackageInfo(it.packageName, 0).versionName } catch (e: Exception) { "" },
                            "permissions" to permissions
                        )
                    }
                    result.success(apps)
                } else {
                    result.notImplemented()
                }
            }
    }
}
